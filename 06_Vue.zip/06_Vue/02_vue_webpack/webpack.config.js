const path = require('path')

module.exports = {
  entry: {},
  module: {},
  plugins: [],
  output: {},
}